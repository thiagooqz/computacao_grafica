import glfw
from OpenGL.GL import *
import numpy as np

class BandeiraDoBrasil:
    def __init__(self):
        self.larguraBandeira = 300   # tamanho do retangulo
        self.alturaBandeira = 180   # tamanho do retangulo
        self.larguraLosango = 180  # tamanho do losango
        self.alturaLosango = 120  # tamanho do losango
        self.raioCirculo = 50    # raio do circulo

    def draw(self):
        glClearColor(1.0, 1.0, 1.0, 1.0)  # Definir o fundo
        glClear(GL_COLOR_BUFFER_BIT) 
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, 400, 0, 400, -1, 1)

        glColor3f(0.0, 0.0, 0.0)  # Definir as linhas

        # Desenha as linhas do retângulo
        glBegin(GL_LINE_LOOP)
        glVertex2f(50, 110)
        glVertex2f(350, 110)
        glVertex2f(350, 290)
        glVertex2f(50, 290)
        glEnd()

        # Desenha as linhas do losango
        glBegin(GL_LINE_LOOP)
        glVertex2f(200, 110)
        glVertex2f(320, 200)
        glVertex2f(200, 290)
        glVertex2f(80, 200)
        glEnd()

        # Desenha as linhas do círculo
        num_segments = 100
        glBegin(GL_LINE_LOOP)
        for i in range(num_segments):
            theta = 2.0 * np.pi * i / num_segments
            x = self.raioCirculo * np.cos(theta) + 200
            y = self.raioCirculo * np.sin(theta) + 200
            glVertex2f(x, y)
        glEnd()

    def run(self):
        if not glfw.init():
            return

        window = glfw.create_window(400, 400, "Bandeira do Brasil", None, None) # Cria uma janela de renderização
        if not window: # Verifica se a criação da janela foi bem-sucedida
            glfw.terminate()
            return

        glfw.make_context_current(window) # Define a janela criada como o contexto de renderização atual.

        while not glfw.window_should_close(window):
            glfw.poll_events()
            glClear(GL_COLOR_BUFFER_BIT)
            self.draw()
            glfw.swap_buffers(window)

        glfw.terminate()

if __name__ == "__main__":
    bandeira = BandeiraDoBrasil()
    bandeira.run()
